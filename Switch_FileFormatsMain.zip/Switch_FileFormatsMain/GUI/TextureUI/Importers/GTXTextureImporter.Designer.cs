﻿namespace FirstPlugin
{
    partial class GTXTextureImporter
    {

    }
}