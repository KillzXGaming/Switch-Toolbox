﻿using System.Collections.Generic;

namespace FirstPlugin.Turbo.CourseMuuntStructs
{
    public class BasePathGroup
    {
        public bool ConnectGroups = true;

        public List<BasePathPoint> PathPoints = new List<BasePathPoint>();
    }
}
