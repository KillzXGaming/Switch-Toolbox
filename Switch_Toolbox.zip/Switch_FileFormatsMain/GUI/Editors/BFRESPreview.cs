﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PluginExample1.GUI.Editors
{
    public partial class BFRESPreview : UserControl
    {
        public BFRESPreview()
        {
            InitializeComponent();
        }
    }
}
