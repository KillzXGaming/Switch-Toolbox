﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Switch_Toolbox.Library;
using System.Windows.Forms;
using Bfres.Structs;

namespace FirstPlugin
{
    class FormLoader
    {
        public static void LoadEditor(object type, string Text)
        {
       
        }
        public static void LoadEditor(BfresBone bone)
        {
   
        }
    }
}
