﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bfres.Structs;

namespace FirstPlugin
{
    public class AglShaderOdyssey
    {
        public void LoadRenderInfo(BfresRenderInfo renderInfo)
        {

        }
    }
}
