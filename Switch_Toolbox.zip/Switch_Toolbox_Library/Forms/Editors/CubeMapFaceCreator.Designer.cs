﻿namespace Switch_Toolbox.Library.GUI
{
    partial class CubeMapFaceCreator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CubeMapFaceCreator));
            this.pictureBoxCustom6 = new Switch_Toolbox.Library.Forms.PictureBoxCustom();
            this.pictureBoxCustom1 = new Switch_Toolbox.Library.Forms.PictureBoxCustom();
            this.pictureBoxCustom2 = new Switch_Toolbox.Library.Forms.PictureBoxCustom();
            this.pictureBoxCustom3 = new Switch_Toolbox.Library.Forms.PictureBoxCustom();
            this.pictureBoxCustom4 = new Switch_Toolbox.Library.Forms.PictureBoxCustom();
            this.pictureBoxCustom5 = new Switch_Toolbox.Library.Forms.PictureBoxCustom();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom5)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxCustom6
            // 
            this.pictureBoxCustom6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxCustom6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxCustom6.BackgroundImage")));
            this.pictureBoxCustom6.Location = new System.Drawing.Point(217, 12);
            this.pictureBoxCustom6.Name = "pictureBoxCustom6";
            this.pictureBoxCustom6.Size = new System.Drawing.Size(200, 200);
            this.pictureBoxCustom6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCustom6.TabIndex = 5;
            this.pictureBoxCustom6.TabStop = false;
            // 
            // pictureBoxCustom1
            // 
            this.pictureBoxCustom1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxCustom1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxCustom1.BackgroundImage")));
            this.pictureBoxCustom1.Location = new System.Drawing.Point(217, 218);
            this.pictureBoxCustom1.Name = "pictureBoxCustom1";
            this.pictureBoxCustom1.Size = new System.Drawing.Size(200, 200);
            this.pictureBoxCustom1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCustom1.TabIndex = 6;
            this.pictureBoxCustom1.TabStop = false;
            // 
            // pictureBoxCustom2
            // 
            this.pictureBoxCustom2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxCustom2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxCustom2.BackgroundImage")));
            this.pictureBoxCustom2.Location = new System.Drawing.Point(11, 218);
            this.pictureBoxCustom2.Name = "pictureBoxCustom2";
            this.pictureBoxCustom2.Size = new System.Drawing.Size(200, 200);
            this.pictureBoxCustom2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCustom2.TabIndex = 7;
            this.pictureBoxCustom2.TabStop = false;
            // 
            // pictureBoxCustom3
            // 
            this.pictureBoxCustom3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxCustom3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxCustom3.BackgroundImage")));
            this.pictureBoxCustom3.Location = new System.Drawing.Point(217, 424);
            this.pictureBoxCustom3.Name = "pictureBoxCustom3";
            this.pictureBoxCustom3.Size = new System.Drawing.Size(200, 200);
            this.pictureBoxCustom3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCustom3.TabIndex = 8;
            this.pictureBoxCustom3.TabStop = false;
            // 
            // pictureBoxCustom4
            // 
            this.pictureBoxCustom4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxCustom4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxCustom4.BackgroundImage")));
            this.pictureBoxCustom4.Location = new System.Drawing.Point(423, 218);
            this.pictureBoxCustom4.Name = "pictureBoxCustom4";
            this.pictureBoxCustom4.Size = new System.Drawing.Size(200, 200);
            this.pictureBoxCustom4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCustom4.TabIndex = 9;
            this.pictureBoxCustom4.TabStop = false;
            // 
            // pictureBoxCustom5
            // 
            this.pictureBoxCustom5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxCustom5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxCustom5.BackgroundImage")));
            this.pictureBoxCustom5.Location = new System.Drawing.Point(629, 218);
            this.pictureBoxCustom5.Name = "pictureBoxCustom5";
            this.pictureBoxCustom5.Size = new System.Drawing.Size(200, 200);
            this.pictureBoxCustom5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCustom5.TabIndex = 10;
            this.pictureBoxCustom5.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(274, 300);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "FRONT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(488, 300);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 24);
            this.label2.TabIndex = 12;
            this.label2.Text = "RIGHT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(78, 300);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 24);
            this.label3.TabIndex = 13;
            this.label3.Text = "LEFT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(716, 300);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 24);
            this.label4.TabIndex = 14;
            this.label4.Text = "BACK";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(283, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 24);
            this.label5.TabIndex = 15;
            this.label5.Text = "TOP";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(268, 528);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 24);
            this.label6.TabIndex = 16;
            this.label6.Text = "BOTTOM";
            // 
            // CubeMapFaceCreator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(840, 630);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBoxCustom5);
            this.Controls.Add(this.pictureBoxCustom4);
            this.Controls.Add(this.pictureBoxCustom3);
            this.Controls.Add(this.pictureBoxCustom2);
            this.Controls.Add(this.pictureBoxCustom1);
            this.Controls.Add(this.pictureBoxCustom6);
            this.Name = "CubeMapFaceCreator";
            this.Text = "CubeMap Face Creator";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCustom5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Forms.PictureBoxCustom pictureBoxCustom6;
        private Forms.PictureBoxCustom pictureBoxCustom1;
        private Forms.PictureBoxCustom pictureBoxCustom2;
        private Forms.PictureBoxCustom pictureBoxCustom3;
        private Forms.PictureBoxCustom pictureBoxCustom4;
        private Forms.PictureBoxCustom pictureBoxCustom5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}