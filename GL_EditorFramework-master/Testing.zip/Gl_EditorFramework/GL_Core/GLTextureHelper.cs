﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Drawing;
using System.Drawing.Imaging;

namespace OpenGl_EditorFramework.GL_Core
{
    public class GLTextureHelper
    {
        public static void LoadCompressedImage(byte[] data, int width, int height,
            PixelInternalFormat pixelInternalFormat, OpenTK.Graphics.OpenGL.PixelFormat pixelFormat)
        {
            GL.TexImage2D<byte>(TextureTarget.Texture2D, 0, pixelInternalFormat, width, height, 0,
                    pixelFormat, PixelType.UnsignedByte, data);

            GL.GenerateMipmap(GenerateMipmapTarget.Texture2D);
        }

        public static void LoadBitmap(Bitmap bitmap)
        {
            BitmapData data = bitmap.LockBits(new System.Drawing.Rectangle(0, 0, bitmap.Width, bitmap.Height),
            ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, data.Width, data.Height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Bgra, PixelType.UnsignedByte, data.Scan0);
            bitmap.UnlockBits(data);
        }
    }
}
