﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Drawing;

namespace OpenGl_EditorFramework.GL_Core
{
    public abstract class GLTexture
    {
        public int Width { get; protected set; }
        public int Height { get; protected set; }
        public TextureTarget TextureTarget { get; }
        public TextureMinFilter MinFilter { get; set; }
        public TextureMagFilter magFilter { get; set; }
        public TextureWrapMode TextureWrapS { get; set; }
        public TextureWrapMode TextureWrapT { get; set; }
        public TextureWrapMode TextureWrapR { get; set; }

        public int TexID;

        public void Bind()
        {
            GL.BindTexture(TextureTarget, TexID);
        }

        public byte[] GetImageData(int mipLevel)
        {
            int channels = 4;
            byte[] data = new byte[Width * Height * sizeof(byte) * channels];

            GL.GetTexImage(TextureTarget, mipLevel, PixelFormat.Rgba, PixelType.UnsignedByte, data);
            return data;
        }
    }
    public class Texture2D : GLTexture
    {
        public void LoadImageData(byte[] image, int Width, int Height,
            PixelInternalFormat pixelInternalFormat, PixelFormat pixelFormat, PixelType pixelType )
        {
            GL.GenTextures(1, out TexID);
            GL.BindTexture(TextureTarget.Texture2D, TexID);
            LoadDefaultFiltering();
        }
        public void LoadImageData(byte[] image, int Width, int Height,
        PixelInternalFormat pixelInternalFormat)
        {
            GL.GenTextures(1, out TexID);
            GL.BindTexture(TextureTarget.Texture2D, TexID);
            LoadDefaultFiltering();
        }
        public void LoadImageData(Bitmap image)
        {
            GL.GenTextures(1, out TexID);
            GL.BindTexture(TextureTarget.Texture2D, TexID);
            GLTextureHelper.LoadBitmap(image);
            LoadDefaultFiltering();
        }
        private void LoadDefaultFiltering()
        {
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Repeat);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Repeat);
        }
    }
    public class TextureCubeMap : GLTexture
    {
        public void LoadImageData(Bitmap image)
        {
            Width = image.Width;
            Height = image.Height;

            Bind();
        }
    }
}
