﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL;
using OpenTK;
using System.Drawing;
using System.Windows.Forms;
using GL_EditorFramework.Interfaces;
using GL_EditorFramework.StandardCameras;

namespace OpenGl_EditorFramework.GL_Core
{
    public class GL_ControlLegacy2D : GLControl
    {
        public GL_ControlLegacy2D()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // GL_ControlLegacy2D
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.Name = "GL_ControlLegacy2D";
            this.Resize += new System.EventHandler(this.GL_ControlLegacy2D_Resize);
            this.ResumeLayout(false);

        }

        protected Matrix4 mtxProj;

        protected AbstractCamera2D activeCamera;
        public AbstractCamera2D ActiveCamera
        {
            get => activeCamera;
            set
            {
                if (value == null) return;
                activeCamera = value;
                MakeCurrent();
                Refresh();
            }
        }

        private void GL_ControlLegacy2D_Resize(object sender, EventArgs e)
        {
            if (DesignMode) return;

            float aspect_ratio;
            aspect_ratio = Width / (float)Height;

            Refresh();
        }

        protected AbstractGlDrawable mainDrawable;
        public virtual AbstractGlDrawable MainDrawable { get; set; }


        private bool shouldRedraw;
        private bool shouldRepick;
        private bool skipCameraAction;

        protected override void OnLoad(EventArgs e)
        {
            if (DesignMode) return;

            activeCamera = new Camera2D();

        }

        void handleCameraEvtResult(uint result)
        {
            shouldRedraw |= result > 0;
            shouldRepick |= result > 0;
        }

        void handleDrawableEvtResult(uint result)
        {
            shouldRedraw |= (result & AbstractGlDrawable.REDRAW) > 0;
            shouldRepick |= (result & AbstractGlDrawable.REPICK) > 0;
            skipCameraAction |= (result & AbstractGlDrawable.NO_CAMERA_ACTION) > 0;
        }
    }
}
