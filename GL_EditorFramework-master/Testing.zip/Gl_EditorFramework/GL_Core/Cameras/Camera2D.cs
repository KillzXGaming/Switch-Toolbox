﻿using GL_EditorFramework.Interfaces;
using OpenTK;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GL_EditorFramework.StandardCameras
{
    public class Camera2D : AbstractCamera2D
    {
        private float maxCamMoveSpeed;

        public Camera2D(float maxCamMoveSpeed = 0.1f)
        {
            this.maxCamMoveSpeed = maxCamMoveSpeed;
        }

        public override uint MouseDown(MouseEventArgs e, I2DControl control)
        {
            if (OpenTK.Input.Keyboard.GetState().IsKeyDown(OpenTK.Input.Key.ControlLeft) &&
                e.Button == MouseButtons.Right &&
                control.PickingDepth != control.ZFar)
            {
             
            }
            base.MouseDown(e, control);
            return UPDATE_CAMERA;
        }

        public override uint MouseMove(MouseEventArgs e, Point lastMouseLoc, I2DControl control)
        {
            float deltaX = e.Location.X - lastMouseLoc.X;
            float deltaY = e.Location.Y - lastMouseLoc.Y;

     
            return 0;
        }

        public override uint MouseWheel(MouseEventArgs e, I2DControl control)
        {
      
            return UPDATE_CAMERA;
        }
    }
}
