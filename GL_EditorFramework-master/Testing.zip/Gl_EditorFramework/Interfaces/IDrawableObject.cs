﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL;
using OpenTK;

namespace OpenGl_EditorFramework.Interfaces
{
    public abstract class IDrawableObject<T> where T : struct
    {

    }
}
