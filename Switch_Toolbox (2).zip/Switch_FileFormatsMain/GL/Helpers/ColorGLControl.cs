﻿using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace FirstPlugin
{
    public class ColorGLControl
    {
        public Vector4 BlendColorConst = new Vector4(1, 1, 1, 1);

        public void LoadRenderPass()
        {

        }
    }
}
